export default function FrameBuilderPage() {
  return (
    <div className='space-y-4'>
      <h1 className='text-2xl font-semibold'>AI Frame Builder</h1>
      <p className='text-slate-300'>
        AI frame builder + cloners wired to FrameAgent and FarcasterFrameRegistry will render here.
      </p>
    </div>
  );
}
