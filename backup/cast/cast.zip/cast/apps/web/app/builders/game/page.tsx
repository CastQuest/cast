export default function GameBuilderPage() {
  return (
    <div className='space-y-4'>
      <h1 className='text-2xl font-semibold'>AI Game Builder</h1>
      <p className='text-slate-300'>
        AI game builder wired to GameAgent and SDK will render here.
      </p>
    </div>
  );
}
