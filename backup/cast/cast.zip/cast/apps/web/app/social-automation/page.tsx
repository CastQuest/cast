export default function SocialAutomationPage() {
  return (
    <div className='space-y-4'>
      <h1 className='text-2xl font-semibold'>Social Automation</h1>
      <p className='text-slate-300'>
        Reddit / X / Discord / Telegram automation flows will render here.
      </p>
    </div>
  );
}
