export default function TokensPage() {
  return (
    <div className='space-y-4'>
      <h1 className='text-2xl font-semibold'>Tokens</h1>
      <p className='text-slate-300'>
        User tokens, launch flows, and token stats will render here.
      </p>
    </div>
  );
}
