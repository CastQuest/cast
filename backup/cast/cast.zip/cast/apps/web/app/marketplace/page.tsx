export default function MarketplacePage() {
  return (
    <div className='space-y-4'>
      <h1 className='text-2xl font-semibold'>Global Marketplace</h1>
      <p className='text-slate-300'>
        Global multi-chain marketplace, auctions, sponsor market, and L3 markets will render here.
      </p>
    </div>
  );
}
