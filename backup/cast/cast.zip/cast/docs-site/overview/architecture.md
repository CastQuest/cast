# CASTQUEST V3 Architecture

See v3-architecture.svg in apps/web/public/assets/diagrams for the visual architecture.  
This document will describe each layer in detail.
