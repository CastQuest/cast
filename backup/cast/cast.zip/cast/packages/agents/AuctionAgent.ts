// CASTQUEST V3 Agent stub.
// Implement according to CASTQUEST V3 Master Spec.
export class AgentStub {}
